package com.example.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.domain.Productos;
import com.example.domain.Usuario;
import com.example.domain.Valoracion;
import com.example.repository.ValoracionRepository;


@Service
public class ValoracionServiceImpl implements ValoracionServicio {
    @Autowired
    ValoracionRepository repositorio;

    public Valoracion add(Valoracion valoracion) {
        return repositorio.save(valoracion);
    }

    public Valoracion findById(Long id) {
        return repositorio.findById(id).orElse(null);
    }

    public void delete(Valoracion valoracion) {
        repositorio.delete(valoracion);
    }

    public List<Valoracion> findByProductos(Productos productos) {
        return repositorio.findByProductos(productos);
    }

    public List<Valoracion> findByUsuario(Usuario usuario) {
        return repositorio.findByUsuario(usuario);
    }

    public Valoracion findByProductosAndUsuario(Productos pro, Usuario usu) {
        return repositorio.findByProductosAndUsuario(pro, usu);
    }
}
