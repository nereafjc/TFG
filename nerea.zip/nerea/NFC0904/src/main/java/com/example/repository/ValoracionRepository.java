package com.example.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.domain.Productos;
import com.example.domain.Usuario;
import com.example.domain.Valoracion;


public interface ValoracionRepository extends JpaRepository<Valoracion, Long> {
    List<Valoracion> findByProductos(Productos productos);

    List<Valoracion> findByUsuario(Usuario usuario);

    Valoracion findByProductosAndUsuario(Productos pro, Usuario usu);
}
