package com.example.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.domain.Categoria;
import com.example.domain.Productos;


public interface ProductoRepository extends JpaRepository<Productos, Long> {
    List<Productos> findByCategoria(Categoria categoria);
    Productos findByNombre(String Nombre);
}
