package com.example.domain;

public enum TipoIva {SUPERREDUCIDO, REDUCIDO, NORMAL};
