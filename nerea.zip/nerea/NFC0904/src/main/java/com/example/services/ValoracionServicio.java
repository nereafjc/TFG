package com.example.services;

import java.util.List;

import com.example.domain.Productos;
import com.example.domain.Usuario;
import com.example.domain.Valoracion;


public interface ValoracionServicio {
    public Valoracion findById(Long id);

    public Valoracion add(Valoracion valoracion);

    public void delete(Valoracion valoracion);

    public List<Valoracion> findByProductos(Productos productos);

    public List<Valoracion> findByUsuario(Usuario usuario);

    public Valoracion findByProductosAndUsuario(Productos pro, Usuario usu);
}
