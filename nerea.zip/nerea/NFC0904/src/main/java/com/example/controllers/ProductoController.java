package com.example.controllers;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
// import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.domain.Productos;
import com.example.services.CategoriaServicelmplMen;
import com.example.services.ProductoServiceImplMem;



@Controller
@RequestMapping("/productos")
public class ProductoController {

    @Autowired
    ProductoServiceImplMem productoService;

    @Autowired
    CategoriaServicelmplMen categoriaService;

    @GetMapping({ "/", "/list",""})
    public String showList(Model model) {
        model.addAttribute("listaProductos", productoService.findAll());
        model.addAttribute("listaCategorias", categoriaService.findAll());
        model.addAttribute("categoriaSeleccionada", "Todas");
        return "product/productosList";
    }

    @GetMapping("/list/{idCat}")
    public String showListInCategory(@PathVariable Long idCat, Model model) {
        // model.addAttribute("listaProductos", productoService.findByCategoria(idCat));
        model.addAttribute("listaProductos", productoService.findByCategoria(categoriaService.findById(idCat)));
        model.addAttribute("listaCategorias", categoriaService.findAll());
        model.addAttribute("categoriaSeleccionada", categoriaService.findById(idCat).getNombre());
        return "product/productosList";
    }

    @GetMapping("/new")
    public String showNew(Model model) {
        // el commandobject del formulario es una instancia de producto vacia
        model.addAttribute("productoForm", new Productos());
        model.addAttribute("listaCategorias", categoriaService.findAll());
        return "product/productosNewView";
    }

    @PostMapping("/new/submit")
    public String showNewSubmit(
            @Valid @ModelAttribute("productoForm") Productos nuevoProducto,
            BindingResult bindingResult) {
        if (bindingResult.hasErrors())
            return "newForm";
        productoService.add(nuevoProducto);
        return "redirect:/productos/list";
    }

    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable long id, Model model) {
        Productos producto = productoService.findById(id);
        // el commandobject del formulario es el producto con el id solicitado
        if (producto != null) {
            model.addAttribute("productoForm", producto);
            model.addAttribute("listaCategorias", categoriaService.findAll());
            return "product/productosEditView";
        }
        // si no lo encuentra vuelve a la página de inicio.
        return "redirect:/productos";
    }

    @PostMapping("/edit/submit")
    public String showEditSubmit(
            @Valid @ModelAttribute("productoForm") Productos producto,
            BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            return "product/productosEditView";
        } else {
            productoService.edit(producto);
            return "redirect:/productos/list";
        }
    }

    @GetMapping("/delete/{id}")
    public String showDelete(@PathVariable long id) {
        productoService.delete(id);
        return "redirect:/productos/list";
    }
}
