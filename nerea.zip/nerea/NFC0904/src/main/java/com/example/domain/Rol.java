package com.example.domain;

public enum Rol {
    USER, MANAGER, ADMIN
};
