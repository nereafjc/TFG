package com.example;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.example.domain.Categoria;
import com.example.domain.Productos;
import com.example.domain.Rol;
import com.example.domain.TipoIva;
import com.example.domain.Usuario;
import com.example.domain.Valoracion;
import com.example.services.CategoriaServicelmplMen;
import com.example.services.ProductoServiceImplMem;
import com.example.services.UsuarioService;
import com.example.services.ValoracionServiceImpl;

@SpringBootApplication
public class TiendaApplication {

	public static void main(String[] args) {
		SpringApplication.run(TiendaApplication.class, args);
	}
	
	@Bean
	CommandLineRunner initData(ProductoServiceImplMem productosService, CategoriaServicelmplMen categoriaService, ValoracionServiceImpl valoracionServicio, UsuarioService usuarioService) {
		return args -> {
			categoriaService.add(new Categoria( "lacteo"));
			categoriaService.add(new Categoria("harina"));
			usuarioService.add(new Usuario("juan","22-12-2012", "1234", Rol.ADMIN));
			usuarioService.add(new Usuario("pepe", "22-12-2022", "1234", Rol.USER));
			usuarioService.add(new Usuario("antonio", "22-12-2012", "1234", Rol.MANAGER));
			productosService.add(
					new Productos("leche", true, TipoIva.REDUCIDO, 2.00,  categoriaService.findByNombre("lacteo")));
			productosService.add(
					new Productos("harina", false, TipoIva.REDUCIDO, 5, categoriaService.findByNombre("harina")));
					valoracionServicio.add(new Valoracion(4,productosService.findByNombre("leche"), usuarioService.findByNombre("Antonio"), "puede ser mejor"));
		};

	}

}
