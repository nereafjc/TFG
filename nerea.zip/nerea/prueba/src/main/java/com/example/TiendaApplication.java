package com.example;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.example.domain.Categoria;
import com.example.domain.Productos;
import com.example.domain.Rol;
import com.example.domain.Usuario;
import com.example.services.CategoriaServicelmplMen;
import com.example.services.ProductoServiceImplMem;
import com.example.services.UsuarioService;
import com.example.services.ValoracionServiceImpl;

@SpringBootApplication
public class TiendaApplication {

	public static void main(String[] args) {
		SpringApplication.run(TiendaApplication.class, args);
	}

	@Bean
	CommandLineRunner initData(ProductoServiceImplMem productosService, CategoriaServicelmplMen categoriaService,
			ValoracionServiceImpl valoracionServicio, UsuarioService usuarioService) {
		return args -> {
			categoriaService.add(new Categoria("Novios"));
			categoriaService.add(new Categoria("Familia novia"));
			categoriaService.add(new Categoria("Familia novio"));
			categoriaService.add(new Categoria("Amigos comunes"));
			categoriaService.add(new Categoria("Amigos novia"));
			categoriaService.add(new Categoria("Amigos novio"));
			categoriaService.add(new Categoria("Trabajo novia"));
			categoriaService.add(new Categoria("Trabajo novio"));

			usuarioService.add(new Usuario("juan", "22-12-2012", "1234", Rol.ADMIN));
			usuarioService.add(new Usuario("pepe", "22-12-2022", "1234", Rol.USER));
			usuarioService.add(new Usuario("nerea", "22/12/2021", "1234", Rol.USER));
			usuarioService.add(new Usuario("antonio", "22-12-2012", "1234", Rol.MANAGER));
			productosService.add(
					new Productos("Juan", "648574588", "juan@example.com", "Ronda de outeiro",
							categoriaService.findByNombre("Amigos comunes")));
			productosService.add(
					new Productos("Ana", "6478584854", "ana@example.com", "Ronda de nelle",
							categoriaService.findByNombre("Amigos comunes")));

		};

	}

}
