var tareasPendientes = [];
var tareasCompletadas = [];

function agregarTarea() {
	var nombre = document.getElementById("nombre").value;
	var descripcion = document.getElementById("descripcion").value;
	var categoria = document.getElementById("categoria").value;
	var fecha = document.getElementById("fecha").value;

	if (nombre == "" || descripcion == "" || categoria == "" || fecha == "") {
		alert("Por favor, completa todos los campos");
		return;
	}

	var tarea = {
		nombre: nombre,
		descripcion: descripcion,
		categoria: categoria,
		fecha: fecha
	};

	tareasPendientes.push(tarea);

	actualizarListaTareas();
}

function actualizarListaTareas() {
	var listaTareasPendientes = document.getElementById("tareasPendientes");
	var listaTareasCompletadas = document.getElementById("tareasCompletadas");

	listaTareasPendientes.innerHTML = "";
	listaTareasCompletadas.innerHTML = "";

	for (var i = 0; i < tareasPendientes.length; i++) {
		var tarea = tareasPendientes[i];
		var li = document.createElement("li");

		// Mostrar el nombre de la tarea y la fecha
		var texto = document.createTextNode(tarea.nombre + " (" + tarea.fecha + ")");
		li.appendChild(texto);

		// Mostrar la descripción de la tarea
		var descripcion = document.createElement("p");
		descripcion.innerHTML = tarea.descripcion;
		li.appendChild(descripcion);

		// Mostrar la categoría de la tarea
		var categoria = document.createElement("span");
		categoria.innerHTML = tarea.categoria;
		categoria.className = "categoria";
		li.appendChild(categoria);

		// Agregar el botón para completar la tarea
		var botonCompletado = document.createElement("button");
		botonCompletado.innerHTML = "Completado";
		botonCompletado.addEventListener("click", completarTarea.bind(null, i));
		li.appendChild(botonCompletado);

		listaTareasPendientes.appendChild(li);
	}

	for (var i = 0; i < tareasCompletadas.length; i++) {
		var tarea = tareasCompletadas[i];
		var li = document.createElement("li");

		// Mostrar el nombre de la tarea y la fecha
		var texto = document.createTextNode(tarea.nombre + " (" + tarea.fecha + ")");
		li.appendChild(texto);

		// Mostrar la descripción de la tarea
		var descripcion = document.createElement("p");
		descripcion.innerHTML = tarea.descripcion;
		li.appendChild(descripcion);

		// Mostrar la categoría de la tarea
		var categoria = document.createElement("span");
		categoria.innerHTML = tarea.categoria;
		categoria.className = "categoria";
		li.appendChild(categoria);

		listaTareasCompletadas.appendChild(li);
	}
}


function completarTarea(index) {
var tareaCompletada = tareasPendientes.splice(index, 1)[0];
tareasCompletadas.push(tareaCompletada);
actualizarListaTareas();
}

actualizarListaTareas();


