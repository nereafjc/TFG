package com.example.domain;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(of = "id")

@Entity
public class Usuario {

    @Id
    @GeneratedValue
    long id;
    String nombre;
    String fechaRegistro;
    String password;
    Rol rol;

    public Usuario(String nombre, String fechaRegistro, String password, Rol rol) {
        this.nombre = nombre;
        this.fechaRegistro = fechaRegistro;
        this.password = password;
        this.rol = rol;
    }

}
