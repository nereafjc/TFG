package com.example.services;

import java.util.List;

import com.example.domain.Categoria;
import com.example.domain.Productos;


public interface ProductoService {
    public Productos add(Productos p);
    public List<Productos> findAll();
    public Productos findById(long id);
    public Productos edit(Productos p);
    public void delete(Long id);
    public List<Productos> findByCategoria(Categoria categoria);
    public Productos findByNombre(String nombre);
}
